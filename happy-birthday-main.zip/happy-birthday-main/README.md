# happy-birthday
For your Love


Webnyo lihat sini yah : [https://himangmyid.github.io/](https://himangmyid.github.io/happy-birthday/)


## Script HTML CCS selamt Ulang Tahun Simple Download Saja


## If you want to change the code above for your loved ones I can help by giving me support:

https://paypal.me/DogGhozt

https://tako.id/@himang/gift


## Support Me 

[<img alt="Paypal"  src="https://www.paypalobjects.com/digitalassets/c/website/logo/full-text/pp_fc_hl.svg" />](https://paypal.me/DogGhozt) 

[<img alt="Tako.id" width="200" src="https://tako.id/_next/static/media/logo.50498557.svg" />](https://tako.id/@himang/gift)


<a href="https://www.buymeacoffee.com/himang" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>

